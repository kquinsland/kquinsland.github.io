#if !defined(AFX_SNTP_H__8CE23CB6_979A_427F_9C34_139FF2050F43__INCLUDED_)
#define AFX_SNTP_H__8CE23CB6_979A_427F_9C34_139FF2050F43__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SNTP.h : header file
//
#include "NetModuleProtocol.h"
#include "Resource.h"
/////////////////////////////////////////////////////////////////////////////
// SNTP dialog
extern  char pcmac[6];										//��ǰMAC��ַ
extern  char pcip[16];										//��ǰIP
class SNTP : public CDialog
{
// Construction
public:
	SNTP(CWnd* pParent = NULL);   // standard constructor
    UINT NUM;
	CWnd* pParent;

    UINT protype_fir,protype_sec;
	BOOL SNTPEnFlag;
    void ShowSNTP(pnet_comm pcmm, int Socket_Num);
	void GetSNTP(pnet_comm pcmm,int GSock_Num);

// Dialog Data
	//{{AFX_DATA(SNTP)
	enum { IDD = IDD_SNTP_DIALOG};
	UINT  m_sntp_enablef;
	UINT  m_sntp_type;
	CIPAddressCtrl	m_sntp_destip;
	CString	m_rolltime;
	CEdit   m_edit_rolltime;
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SNTP)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(SNTP)
	afx_msg void OnCheckEnableSNTP();
	afx_msg void OnProChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SNTP_H__8CE23CB6_979A_427F_9C34_139FF2050F43__INCLUDED_)
