#if !defined(AFX_AIR_STATUS_H__A63B4E3B_6FD2_41D8_8848_3A522896918A__INCLUDED_)
#define AFX_AIR_STATUS_H__A63B4E3B_6FD2_41D8_8848_3A522896918A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AIR_STATUS.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// AIR_STATUS dialog

class AIR_STATUS : public CDialog
{
// Construction
public:
	void showStatus(int controller);
	int num;
	AIR_STATUS(CWnd* pParent = NULL);   // standard constructor
	AIR_STATUS(CWnd* pParent,int num); 
// Dialog Data
	//{{AFX_DATA(AIR_STATUS)
	enum { IDD = IDD_DIALOG_AIR_INFO };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AIR_STATUS)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(AIR_STATUS)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancelMode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AIR_STATUS_H__A63B4E3B_6FD2_41D8_8848_3A522896918A__INCLUDED_)
