#if !defined(AFX_PORT_H__0E96156D_FBC9_4D4A_8B2F_0A6B750BD513__INCLUDED_)
#define AFX_PORT_H__0E96156D_FBC9_4D4A_8B2F_0A6B750BD513__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "NetModuleProtocol.h"

/////////////////////////////////////////////////////////////////////////////
// CSocket dialog
extern  char pcmac[6];										//��ǰMAC��ַ
extern  char pcip[16];										//��ǰIP
class CSocket : public CDialog
{
// Construction
public:
	UINT NUM;
    UINT seed,protype_fir,protype_sec;
	UINT SeedSet[100];
	BOOL SocketEnFlag;
    void ShowSocket(pnet_comm pcmm, int Socket_Num);
	void GetSocket(pnet_comm pcmm,int GSock_Num);
	CSocket(CWnd* pParent = NULL);   // standard constructor
	CWnd* pParent;
// Dialog Data
	//{{AFX_DATA(CSocket)
	enum { IDD = IDD_SOCKET_DIALOG };
	UINT  m_enablef;
	UINT  m_type;
	UINT  m_PHYOFFDealType;
	UINT  m_OtherChannDeal;
	CIPAddressCtrl	m_dest_ip_socket;
    CString m_des_port_socket;
    CString m_loc_port_socket;
    CEdit   m_edit_desport;
	CEdit   m_edit_locport;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSocket)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSocket)
	afx_msg void OnCheckEnableSocket();
	afx_msg void OnCheckPortRandom();
	afx_msg void OnProType();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PORT_H__0E96156D_FBC9_4D4A_8B2F_0A6B750BD513__INCLUDED_)
