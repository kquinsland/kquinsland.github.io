// NetModuleConfig.h : main header file for the NETMODULECONFIG application
//

#if !defined(AFX_NETMODULECONFIG_H__3308F275_1120_4688_B5CB_BE5E2F48A69D__INCLUDED_)
#define AFX_NETMODULECONFIG_H__3308F275_1120_4688_B5CB_BE5E2F48A69D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CNetModuleConfigApp:
// See NetModuleConfig.cpp for the implementation of this class
//

class CNetModuleConfigApp : public CWinApp
{
public:
	CNetModuleConfigApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetModuleConfigApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CNetModuleConfigApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETMODULECONFIG_H__3308F275_1120_4688_B5CB_BE5E2F48A69D__INCLUDED_)
