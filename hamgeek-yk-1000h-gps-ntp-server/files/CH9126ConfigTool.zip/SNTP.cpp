// SNTP.cpp : implementation file
//
#include "stdafx.h"
#include "SNTP.h"
#include "NetModuleConfigDlg.h"
#include "NetModuleProtocol.h"
#include <time.h>
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern char dest_mac[6];
extern char	pcmac[6] ;								//��ǰMAC��ַ
extern CHAR	pcip[16] ;								//��ǰIP
extern PARA_CFG_MAN	  comm_cmd_send;										//ͨ������ṹ
/////////////////////////////////////////////////////////////////////////////
// SNTP dialog

SNTP::SNTP(CWnd* pParent /*=NULL*/)
	: CDialog(SNTP::IDD, pParent)
{
	//{{AFX_DATA_INIT(SNTP)
	m_sntp_enablef=1;
	m_sntp_type=0;
	//}}AFX_DATA_INIT
}
void SNTP::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SNTP)        
	DDX_Control(pDX,IDC_SNTP_IP, m_sntp_destip);
	DDX_Text(pDX,IDC_SNTP_ROLLTIME, m_rolltime);
	DDX_Control(pDX,IDC_SNTP_ROLLTIME, m_edit_rolltime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(SNTP, CDialog)
	//{{AFX_MSG_MAP(SNTP)
	ON_BN_CLICKED(IDC_SNTP_EN, OnCheckEnableSNTP)
	ON_CBN_SELCHANGE(IDC_SNTP_PROTYPE,OnProChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SNTP message handlers
void SNTP::OnCheckEnableSNTP()
{	
	SNTPEnFlag = ((CButton*)GetDlgItem(IDC_SNTP_EN))->GetCheck();
	if(SNTPEnFlag)
	{
		
		GetDlgItem(IDC_SNTP_PROTYPE)->EnableWindow(TRUE);
		protype_fir=((CComboBox*)GetDlgItem(IDC_SNTP_PROTYPE))->GetCurSel();
	    if(protype_fir==0)
		{
			GetDlgItem(IDC_SNTP_IP)->EnableWindow(FALSE);
			GetDlgItem(IDC_SNTP_OUTEN)->EnableWindow(TRUE);
			GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(FALSE);
		}
		else if(protype_fir==1)
		{
			GetDlgItem(IDC_SNTP_IP)->EnableWindow(TRUE);
			GetDlgItem(IDC_SNTP_OUTEN)->EnableWindow(TRUE);
			GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(TRUE);
		}
	}
	else
	{
		GetDlgItem(IDC_SNTP_PROTYPE)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_OUTEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(FALSE);		
  }
}

void SNTP::OnProChange()
{
	protype_sec=((CComboBox*)GetDlgItem(IDC_SNTP_PROTYPE))->GetCurSel();
    if(protype_sec==1)
	{
		GetDlgItem(IDC_SNTP_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_SNTP_OUTEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(TRUE);
	}
	else if(protype_sec==0)
	{
		GetDlgItem(IDC_SNTP_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_OUTEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(FALSE);
	}
}

void SNTP::ShowSNTP(pnet_comm pcmm,int Socket_Num)
{
	((CButton*)GetDlgItem(IDC_SNTP_EN))->SetCheck(pcmm->SocketConfig[Socket_Num].EnableF);  //SNTPʹ��
	
	if(!(pcmm->SocketConfig[Socket_Num].EnableF))
	{
		GetDlgItem(IDC_SNTP_PROTYPE)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_OUTEN)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(FALSE);	
	}
	else
	{
		GetDlgItem(IDC_SNTP_PROTYPE)->EnableWindow(TRUE);
		GetDlgItem(IDC_SNTP_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_SNTP_OUTEN)->EnableWindow(TRUE);
		GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(TRUE);	
	}
	((CComboBox*)GetDlgItem(IDC_SNTP_PROTYPE))->SetCurSel(pcmm->SocketConfig[Socket_Num].Type-5);	//��ȡЭ������										
	if(pcmm->SocketConfig[Socket_Num].Type == SNTP_Server&&(pcmm->SocketConfig[Socket_Num].EnableF))
	{
		GetDlgItem(IDC_SNTP_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(FALSE);	
		((CButton*)GetDlgItem(IDC_SNTP_OUTEN))->SetCheck(pcmm->NetCfg.CtrlPara%256);  //�������ʹ��
	}
	else if(pcmm->SocketConfig[Socket_Num].Type == SNTP_Client&&(pcmm->SocketConfig[Socket_Num].EnableF))
	{
		GetDlgItem(IDC_SNTP_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_SNTP_ROLLTIME)->EnableWindow(TRUE);
		((CButton*)GetDlgItem(IDC_SNTP_OUTEN))->SetCheck(pcmm->NetCfg.CtrlPara%256);  //�������ʹ��
		m_sntp_destip.SetAddress(pcmm->SocketConfig[Socket_Num].DesIP[0],pcmm->SocketConfig[Socket_Num].DesIP[1],
			pcmm->SocketConfig[Socket_Num].DesIP[2],pcmm->SocketConfig[Socket_Num].DesIP[3]);     //Ŀ��IP
		m_rolltime.Format("%d",pcmm->SocketConfig[Socket_Num].DesPort);          //SNTPģʽ��Ŀ�Ķ˿ڴ洢��ѯ�������
		((CWnd*)GetDlgItem(IDC_SNTP_ROLLTIME))->SetWindowText(m_rolltime);       //��ѯ���
	}
}

void SNTP::GetSNTP(pnet_comm pcmm,int GSock_Num)
{
	char msg[6]= "0";
	pcmm->SocketConfig[GSock_Num].EnableF = (UCHAR)((CButton*)GetDlgItem(IDC_SNTP_EN))->GetCheck();
	if(pcmm->SocketConfig[GSock_Num].EnableF)
	{   
		
		pcmm->SocketConfig[GSock_Num].Type = ((CComboBox*)(GetDlgItem(IDC_SNTP_PROTYPE)))->GetCurSel()+5; 
		if(((CComboBox*)(GetDlgItem(IDC_SNTP_PROTYPE)))->GetCurSel()==1)
		{
		//	AfxMessageBox("1");
			m_sntp_destip.GetAddress(pcmm->SocketConfig[GSock_Num].DesIP[0],pcmm->SocketConfig[GSock_Num].DesIP[1],
				pcmm->SocketConfig[GSock_Num].DesIP[2],pcmm->SocketConfig[GSock_Num].DesIP[3]);       //Ŀ��IP
			pcmm->NetCfg.CtrlPara = (UCHAR)((CButton*)GetDlgItem(IDC_SNTP_OUTEN))->GetCheck();  //�������ʹ��
			memset(msg,0,6);
			((CWnd*)GetDlgItem(IDC_SNTP_ROLLTIME))->GetWindowText(msg,6);
			pcmm->SocketConfig[GSock_Num].DesPort = atoi(msg);
		//	pcmm->SocketConfig[GSock_Num].SourPort = atoi(m_rolltime);
	
		}
		else //if(((CComboBox*)(GetDlgItem(IDC_PRO_TYPE)))->GetCurSel()==0)
		{
		//	AfxMessageBox("0");
			pcmm->NetCfg.CtrlPara = (UCHAR)((CButton*)GetDlgItem(IDC_SNTP_OUTEN))->GetCheck();  //�������ʹ��
		}
	}
}