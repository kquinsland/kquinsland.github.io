// Port.cpp : implementation file
//

#include "stdafx.h"
#include "netmoduleconfig.h"
#include "Socket.h"
#include "NetModuleConfigDlg.h"
#include "NetModuleProtocol.h"
#include <time.h>
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern char dest_mac[6];
extern char	pcmac[6] ;								//��ǰMAC��ַ
extern CHAR	pcip[16] ;								//��ǰIP
extern PARA_CFG_MAN	  comm_cmd_send;										//ͨ������ṹ
/////////////////////////////////////////////////////////////////////////////
// CPort dialog


CSocket::CSocket(CWnd* pParent /*=NULL*/)
	: CDialog(CSocket::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSocket)
	m_enablef=1;
	m_type=0;
 //   m_des_port_socket=_T("0");
 //   m_loc_port_socket=_T("0");
	//}}AFX_DATA_INIT
}

void CSocket::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSocket)
	DDX_Control(pDX, IDC_IPADDRESS_DEST_IP, m_dest_ip_socket);
	DDX_Control(pDX,IDC_EDIT_DEST_PORT,m_edit_desport);
	DDX_Control(pDX,IDC_EDIT_NET_PORT,m_edit_locport);
	DDX_Text(pDX, IDC_EDIT_DEST_PORT, m_des_port_socket);
	DDX_Text(pDX, IDC_EDIT_NET_PORT, m_loc_port_socket);
  //  UINT  m_PHYOFFDealType;
//	UINT  m_OtherChannDeal; 
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSocket, CDialog)
	//{{AFX_MSG_MAP(CSocket)
	ON_BN_CLICKED(IDC_SOCK_EN, OnCheckEnableSocket)
	ON_BN_CLICKED(IDC_CHECK_PORT_RANDOM, OnCheckPortRandom)
	ON_CBN_SELCHANGE(IDC_PRO_TYPE,OnProType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSocket message handlers
 

void CSocket::OnCheckEnableSocket()
{	
	SocketEnFlag = ((CButton*)GetDlgItem(IDC_SOCK_EN))->GetCheck();
	if(SocketEnFlag)
	{
		
		GetDlgItem(IDC_PRO_TYPE)->EnableWindow(TRUE);
		protype_fir=((CComboBox*)GetDlgItem(IDC_PRO_TYPE))->GetCurSel();
		if(protype_fir==3)
		{
			GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(TRUE);
		}
		else if (protype_fir==2)
		{
			GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(FALSE);
			GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(FALSE);
		}
		else  if(protype_fir==0)
		{
			GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
			GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(FALSE);
			GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(FALSE);
		}
		else  if(protype_fir==1)
		{
			GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(TRUE);
			GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(TRUE);
			GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(TRUE);
		}
	}
	else
	{
		GetDlgItem(IDC_PRO_TYPE)->EnableWindow(FALSE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(FALSE);
		GetDlgItem(IDC_PHYOFFDealType)->EnableWindow(FALSE);
		GetDlgItem(IDC_OtherChannDeal)->EnableWindow(FALSE);
	}
}

void CSocket::ShowSocket(pnet_comm pcmm,int Socket_Num)
{
	((CButton*)GetDlgItem(IDC_SOCK_EN))->SetCheck(pcmm->SocketConfig[Socket_Num].EnableF);  //socketʹ��
	
	if(!(pcmm->SocketConfig[Socket_Num].EnableF))
	{
		GetDlgItem(IDC_PRO_TYPE)->EnableWindow(FALSE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(FALSE);
		GetDlgItem(IDC_OtherChannDeal)->EnableWindow(FALSE);
		GetDlgItem(IDC_PHYOFFDealType)->EnableWindow(FALSE);
		//return;
	}
	else
	{
		GetDlgItem(IDC_PRO_TYPE)->EnableWindow(TRUE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(TRUE);
		//	GetDlgItem(IDC_PHYOFFDealType)->EnableWindow(TRUE);
		//	GetDlgItem(IDC_OtherChannDeal)->EnableWindow(TRUE);
	}
	((CComboBox*)GetDlgItem(IDC_PRO_TYPE))->SetCurSel(pcmm->SocketConfig[Socket_Num].Type-1);	//��ȡЭ������										
	
	if(pcmm->SocketConfig[Socket_Num].Type == TCP_Server||pcmm->SocketConfig[Socket_Num].Type == UDP_Server)	
	{
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(FALSE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(FALSE);
		//	GetDlgItem(IDC_PHYOFFDealType)->EnableWindow(TRUE);
		//	((CComboBox*)GetDlgItem(IDC_PHYOFFDealType))->SetCurSel(pcmm->SocketConfig[Socket_Num].PHYOFFDealType);
	}
	else
	{
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(TRUE);
		//	GetDlgItem(IDC_PHYOFFDealType)->EnableWindow(FALSE);
		//	((CComboBox*)GetDlgItem(IDC_PHYOFFDealType))->SetCurSel(pcmm->SocketConfig[Socket_Num].PHYOFFDealType);
	}
	((CComboBox*)GetDlgItem(IDC_OtherChannDeal))->SetCurSel(pcmm->SocketConfig[Socket_Num].OtherChannDeal);
	m_dest_ip_socket.SetAddress(pcmm->SocketConfig[Socket_Num].DesIP[0],
		pcmm->SocketConfig[Socket_Num].DesIP[1],
		pcmm->SocketConfig[Socket_Num].DesIP[2],
		pcmm->SocketConfig[Socket_Num].DesIP[3]);
	
	m_des_port_socket.Format("%d",(char*)pcmm->SocketConfig[Socket_Num].DesPort);  
	
	((CWnd*)GetDlgItem(IDC_EDIT_DEST_PORT))->SetWindowText(m_des_port_socket);
	
	m_loc_port_socket.Format("%d",(char*)pcmm->SocketConfig[Socket_Num].SourPort);  
	
	((CWnd*)GetDlgItem(IDC_EDIT_NET_PORT))->SetWindowText(m_loc_port_socket);  	
}

void CSocket::GetSocket(pnet_comm pcmm,int GSock_Num)
{
	char msg[6]= "0";
	pcmm->SocketConfig[GSock_Num].EnableF = (UCHAR)((CButton*)GetDlgItem(IDC_SOCK_EN))->GetCheck();
	if(pcmm->SocketConfig[GSock_Num].EnableF)
	{   
		pcmm->SocketConfig[GSock_Num].Type = ((CComboBox*)(GetDlgItem(IDC_PRO_TYPE)))->GetCurSel()+1; 
		if(((CComboBox*)(GetDlgItem(IDC_PRO_TYPE)))->GetCurSel()==1 || ((CComboBox*)(GetDlgItem(IDC_PRO_TYPE)))->GetCurSel()==3)
		{
			m_dest_ip_socket.GetAddress(pcmm->SocketConfig[GSock_Num].DesIP[0],pcmm->SocketConfig[GSock_Num].DesIP[1],
				pcmm->SocketConfig[GSock_Num].DesIP[2],pcmm->SocketConfig[GSock_Num].DesIP[3]);
			((CWnd*)GetDlgItem(IDC_EDIT_DEST_PORT))->GetWindowText(msg,6);
			pcmm->SocketConfig[GSock_Num].DesPort =  atoi(msg);//m_des_port_socket);
			memset(msg,0,6);
			((CWnd*)GetDlgItem(IDC_EDIT_NET_PORT))->GetWindowText(msg,6);
			pcmm->SocketConfig[GSock_Num].SourPort = atoi(msg);
		}
		else if(((CComboBox*)(GetDlgItem(IDC_PRO_TYPE)))->GetCurSel()==0 || ((CComboBox*)(GetDlgItem(IDC_PRO_TYPE)))->GetCurSel()==2)
		{
			memset(msg,0,6);
			((CWnd*)GetDlgItem(IDC_EDIT_NET_PORT))->GetWindowText(msg,6);
			pcmm->SocketConfig[GSock_Num].SourPort = atoi(msg);
		}
	}
}

//���洦�����
void CSocket::OnCheckPortRandom() 
{
	if(((CButton*)GetDlgItem(IDC_CHECK_PORT_RANDOM))->GetCheck()==TRUE)
	{
		SeedSet[100] = 0;
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(FALSE);
		srand(time(NULL));
		for(seed=0;seed<100;seed++)
		{
			SeedSet[seed]=rand()%3000+2000;  //����һ����2000��5000֮��������
		}		
		seed=rand()%100;    //�����ȡ���е�һ����
		char msg[20] ="";
		sprintf(msg,"%d",(char*)SeedSet[seed]);
		GetDlgItem(IDC_EDIT_NET_PORT)->SetWindowText(msg);  
	}
	else
	{
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
	}
	UpdateData(TRUE);
}

void CSocket::OnProType()
{
	protype_sec=((CComboBox*)GetDlgItem(IDC_PRO_TYPE))->GetCurSel();
	if(protype_sec==3)
	{
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(TRUE);	
	}
	else if(protype_sec==2)
	{
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(FALSE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(FALSE);
	}
	else if(protype_sec==1)
	{
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(TRUE);
	}
	else if(protype_sec==0)
	{
		GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_NET_PORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_CHECK_PORT_RANDOM)->EnableWindow(FALSE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->EnableWindow(FALSE);
	}
}