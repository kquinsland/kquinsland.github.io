// NetModuleConfigDlg.h : header file
//

#if !defined(AFX_NETMODULECONFIGDLG_H__5FF19D5A_C9C3_4868_9054_378C74457065__INCLUDED_)
#define AFX_NETMODULECONFIGDLG_H__5FF19D5A_C9C3_4868_9054_378C74457065__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//#pragma comment(lib,"ws2_32.lib")
//ģ��Ĭ���������
#define DEFAULT_MODULE_NAME	"NET MODULE"						//Ĭ��ģ����
#define DEFAULT_WORK_TYPE	NET_MODULE_TYPE_UDP_C					//Ĭ�Ϲ���ģʽ
#define DEFAULT_MODULE_IP	"192.168.1.1"							//Ĭ��ģ��IP
#define DEFAULT_MASK		"255.255.255.0"							//Ĭ����������
#define DEFAULT_GETWAY		"192.168.1.2"							//Ĭ������
#define DEFAULT_MODULE_PROT	1124									//Ĭ��ģ��˿�
#define DEFAULT_DEST_IP		"192.168.1.3"							//Ĭ��Ŀ��IP
#define DEFAULT_DEST_PROT	1124									//Ĭ��Ŀ�Ķ˿�
//ģ��Ĭ�ϴ��ڲ���
#define DEFAULT_BOUND		"115200"									//Ĭ�ϲ�����
#define DEFAULT_TIMEOUT		20										//Ĭ�ϳ�ʱ
#define DEFAULT_DATA_BIT	0										//Ĭ������λ
#define DEFAULT_STOP_BIT	0										//Ĭ��ֹͣλ
#define DEFAULT_VERIFY_BIT	NET_MODULE_VERIFY_NULL					//Ĭ��У��λ

#define MODULE_CONFIG_FILE "config.ini\0"							//�����ļ���			

/////////////////////////////////////////////////////////////////////////////
// CNetModuleConfigDlg dialog
#include "TabSheet.h"
#include "Socket.h"
#include "SNTP.h"
#define WM_SHOW WM_USER+1
class CNetModuleConfigDlg : public CDialog
{
// Construction
public:
	CNetModuleConfigDlg(CWnd* pParent = NULL);	// standard constructor
	~CNetModuleConfigDlg();
public:
	void get_mac(int item);								//���豸�б��е�MAC��һ���л�ȡMAC��ַ
	int open_socket();									//����SOCKET
	void log_msg(char* lpformat,...);					//��ʾ��ǰ����״̬���Ƿ�ɹ�
	int get_adapter(int index,BOOL init);				//��ȡ������
	
//	pNetDeviceConfigS pcfg,temp_pcfg;
	CSocket *Socket[2];
	SNTP *Sntp[2];
// Dialog Data
	//{{AFX_DATA(CNetModuleConfigDlg)
	enum { IDD = IDD_NMCFG };
	CTabSheet	    m_socket_tab;
	CIPAddressCtrl	m_dest_ip;
	CIPAddressCtrl	m_gateway;
	CIPAddressCtrl	m_mask;
	CIPAddressCtrl	m_ip;
	CListCtrl		m_mlist;
	CString	m_modulname;
	CString	m_baud;
	CString m_idletime;
	CString m_intervaltime;
	CString m_outcount;
	CString m_mac[6];
	CString	m_dest_port;
	CString	m_packlength;
	CString m_packtimeout;
	CEdit   m_edit_idletime;      //����ʱ��
    CEdit   m_edit_intervaltime;  //���ʱ��
	CEdit   m_edit_outcount;      //��ʱ����
	CEdit   m_edit_modulename;
	CEdit   m_edit_mac0;
	CEdit   m_edit_mac1;
	CEdit   m_edit_mac2;
	CEdit   m_edit_mac3;
	CEdit   m_edit_mac4;
	CEdit   m_edit_mac5;
	CEdit   m_edit_packlength;
	CEdit   m_edit_packtimeout;
	UINT    m_dbits;
	UINT    m_sbits;
	UINT    m_vbits;
	UINT	m_format;
	//}}AFX_DATA
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetModuleConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	
	//}}AFX_VIRTUAL
public:
	BOOL   KeepAliveFlag;
	INT    getconfig();                                   //��ȡ��ǰ����
// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	//{{AFX_MSG(CNetModuleConfigDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSearch();
	afx_msg void OnResetAll();
	afx_msg void OnConfig();
	afx_msg void OnSaveCfg();
	afx_msg void OnLoadCfg();
	afx_msg void OnSelchangeNowadapter();  
	afx_msg void OnButtonRefreshadapter();
	afx_msg void OnCheckEnableSocket();
	afx_msg void EmptyDisplay();
	afx_msg void OnDblclkModuleList();
	afx_msg void OnChangeMac();
	afx_msg void KeepAliveChange();
	afx_msg void OnHelp();
	afx_msg void OnDblclkModuleList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLvnColumnclickList(NMHDR *pNMHDR, LRESULT *pResult);
//	afx_msg LRESULT OnShow(WPARAM wParam,LPARAM lParam);//�Զ�����Ϣ
//	afx_msg void OnCheckPassword();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETMODULECONFIGDLG_H__5FF19D5A_C9C3_4868_9054_378C74457065__INCLUDED_)
