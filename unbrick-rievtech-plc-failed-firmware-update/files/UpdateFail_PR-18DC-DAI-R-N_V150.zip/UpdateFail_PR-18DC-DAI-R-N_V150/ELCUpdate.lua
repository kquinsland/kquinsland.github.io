--
-- ELC PLC hardware update bin file process
-- Copyright EASY
-- 2014/01/10

-- for debug
io.write( "[lua] These args were passed into the script from C/n" ); 

-- note: DON'T modify this code -------------------------------------------------
-- version for software
local version_soft = 0
-- version for hardware
local version_hw = 0
-- ELC model
local model = 0
-- bin file for update application
local binfile_name = ""
-- data array for parameters
local binfile_return_array = {} 

-- get version,model...
version_soft = arg[1]
version_hw = arg[2]
model = arg[3]
-- stop-------------------------------------------------------------------------

-- for debug
print(version_soft)
print(version_hw)
print(model)

io.write("[lua] Script returning data back to C/n") 


-- get bin file name from model
-- default no file
binfile_name = ""

--ELCϵ��*************************************************************	
	if model == 10 or model == 11 or model == 12
	then
	    binfile_name = "VA001-004-001.bin"
	end

 	if model == 5 or model == 6 or model == 7 or model == 8
	then
	    binfile_name = "VA001-002-001.bin"
	end
--ELC_14AC_PT100_R������
	if model == 130
	then
	    binfile_name = "VA001-006-001.bin"
	end

	if model == 17 or model == 18 or model == 21
	then
	    if version_soft <= 30
	    then
			binfile_name = "VA001-003-001.bin"
	    end
	    if version_soft >= 50
	    then
			if version_hw == 3 then
			    binfile_name = "VA001-003-003.bin"
			end
			if version_hw == 103 then
			    binfile_name = "VA001-003-005.bin"
			end
			if version_hw == 203 then
			    binfile_name = "VA001-003-004.bin"
			end
			if version_hw == 210 then
			    binfile_name = "VA001-003-009.bin"
			end
		end
	end

	if model == 19 or model == 20 or model == 22 or model == 23
	then
	    if version_soft <= 30
		then
			binfile_name = "VA001-003-002.bin"
	    end
	    if version_soft >= 50
	    then
			if version_hw == 3 then
			    binfile_name = "VA001-003-006.bin"
			end
			if version_hw == 103 then
			    binfile_name = "VA001-003-008.bin"
			end
			if version_hw == 203 then
			    binfile_name = "VA001-003-007.bin"
			end
			if version_hw == 210 then
			    binfile_name = "VA001-003-010.bin"
			end
		end
	end

	if model== 1 or model == 2 or model == 3 or model == 4
	then
		if version_soft >= 50
		then
			if version_hw == 100
			then
				if version_soft < 100
				then
					binfile_name = "VA001-001-002.bin"
				else
					binfile_name = "VA001-001-003.bin"
				end
			else
				binfile_name = "VA001-001-001.bin"
			end
		end
	end

	if model == 90 or model == 91 or model == 110 or model == 111
	then
		if version_hw == 102
		then
			binfile_name = "VA001-005-001.bin"
		end
		if version_hw == 104
		then
		    binfile_name = "VA001-005-002.bin"
		end
	end

	if model == 92 or model == 112
	then
		if version_hw == 102
		then
		    binfile_name = "VA001-005-003.bin"
		end
		if version_hw == 104
		then
		    binfile_name = "VA001-005-004.bin"
		end
	end

	if model == 94 or model == 114 or model == 101
	then
		if version_hw == 101
		then
		    binfile_name = "VA001-005-005.bin"
		end
		if version_hw == 103
		then
		    binfile_name = "VA001-005-006.bin"
		end
	end

	if model == 95 or model == 115
	then
		if version_hw == 101
		then
		    binfile_name = "VA001-005-007.bin"
		end
		if version_hw == 103
		then
		    binfile_name = "VA001-005-008.bin"
		end
	end
	
--EXMϵ��*************************************************************	
	if model == 61 or model == 64 or model == 68 or model == 71 or
	   model == 82 or model == 60
	then
		if version_hw == 103
		then
			binfile_name = "UA001-001-001.bin"
			binfile_version = FILE_VERSION_UA001_001_001
		end
		if version_hw == 112
		then
			binfile_name = "UA001-001-002.bin"
			binfile_version = FILE_VERSION_UA001_001_002
		end
	end

	if model == 62 or model == 65 or model == 69 or model == 72
	then
		if version_hw == 102
		then
			binfile_name = "UA001-002-001.bin"
			binfile_version = FILE_VERSION_UA001_002_001
		end
		if version_hw == 111
		then
			binfile_name = "UA001-002-002.bin"
			binfile_version = FILE_VERSION_UA001_002_002
		end
	end

	if model == 63 or model == 66 or model == 70 or model == 73
	then
		if version_hw == 101
		then
			binfile_name = "UA001-003-001.bin"
			binfile_version = FILE_VERSION_UA001_003_001
		end
		if version_hw == 110
		then
			binfile_name = "UA001-003-002.bin"
			binfile_version = FILE_VERSION_UA001_003_002
		end
	end

	if model == 83
	then
		if version_hw == 121
		then
			binfile_name = "UA001-004-001.bin"
			binfile_version = FILE_VERSION_UA001_004_001
		end
	end

	if model == 84
	then
		if version_hw == 102
		then
			binfile_name = "UA001-005-001.bin"
			binfile_version = FILE_VERSION_UA001_005_001
		end
		if version_hw == 120
		then
			binfile_name = "UA001-005-002.bin"
			binfile_version = FILE_VERSION_UA001_005_002
		end
	end

	if model == 81
	then
		if version_hw ==  103
		then
			binfile_name = "UA001-001-001.bin"
			binfile_version = FILE_VERSION_UA001_001_001
		end
		if version_hw == 112
		then
			binfile_name = "UA001-001-002.bin"
			binfile_version = FILE_VERSION_UA001_001_002
		end
		if version_hw == 100
		then
			binfile_name = "UA001-001-002.bin"
			binfile_version = FILE_VERSION_UA001_001_002
		end
	end

	if model == 85
	then
		if version_hw == 104
		then
			binfile_name = "UA001-006-001.bin"
			binfile_version = FILE_VERSION_UA001_006_001
		end
		if version_hw == 122
		then
			binfile_name = "UA001-006-002.bin"
			binfile_version = FILE_VERSION_UA001_006_002
		end
	end

	if model == 62
	then
		if version_hw == 100
		then
			binfile_name = "UA001-002-001.bin"
			binfile_version = FILE_VERSION_UA001_002_001
		end
	end
--2014.02.25���ӵ�EXM_12DC_DA_R_N������ 
--2014.04.11���ӵ�EXM_12DC_DA_R_VN������ 
	if model == 86 or model == 87 or model == 77 or model == 80
	then
		if version_hw == 102
		then
			binfile_name = "UA001-007-001.bin"
			binfile_version = FILE_VERSION_UA001_007_001
		end
	end

	if model == 150--2014.02.12���ӵ�RVMC-main������
	then
		if version_hw == 103
		then
			binfile_name = "VM001-001-001.bin"
			binfile_version = FILE_VERSION_VM001_001_001
		end
	end

	if model == 151--2014.02.14���ӵ�RVMC-sms������
	then
		if version_hw == 102
		then
			binfile_name = "VM001-002-001.bin"
			binfile_version = FILE_VERSION_VM001_002_001
		end
	end
--2014.02.14���ӵ�ELC_22AC_R_N������	
	if model == 97
	then
		if version_hw == 102
		then
			binfile_name = "VA001-005-001.bin"
			binfile_version = FILE_VERSION_VA001_005_001
		end
	end
--2014.02.17���ӵ�ELC_12DC_DA_R_N������	
	if model == 88
	then
		if version_hw == 102
		then
			binfile_name = "VA002-001-001.bin"
			binfile_version = FILE_VERSION_VA002_001_001
		end
	end
	
--2014.02.17���ӵ�ELC_12AC_R_N ������	
	if model == 89
	then
		if version_hw == 103
		then
			binfile_name = "VA002-001-002.bin"
			binfile_version = FILE_VERSION_VA002_001_002
		end
	end
--2014.2.25 EXM_12DC_D_R_N
	if model == 76
	then
		if version_hw == 103
		then
			binfile_name = "UA001-007-002.bin"
			binfile_version = FILE_VERSION_VA002_001_002
		end
	end



--end EXMϵ��********************************************	
	

-- stop bin file just


-- note: <<<<DON'T modify this code>>>>
binfile_return_array["version_soft"] = version_soft
binfile_return_array["version_hw"] = version_hw
binfile_return_array["model"] = model
binfile_return_array["binfile"] = binfile_name
return binfile_return_array
-- stop
